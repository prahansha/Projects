# Advanced Task Manager

## Overview
The **Advanced Task Manager** is a console-based application built in Java to help users organize their tasks. Users can add tasks, categorize them, set due dates, and mark them as completed.

## Features
- Add tasks with a title, category, and due date.
- View all tasks with their status (completed or not).
- Mark tasks as completed.
- Simple and intuitive menu-driven interface.

## How to Run
1. Ensure you have JDK 8 or higher installed on your system.
2. Clone the repository or extract the downloaded zip file.
3. Navigate to the `src` directory.
4. Compile the Java files:
   ```
   javac com/unique/taskmanager/*.java
   ```
5. Run the application:
   ```
   java com.unique.taskmanager.App
   ```

## File Structure
```
AdvancedTaskManager/
├── src/
│   └── com/
│       └── unique/
│           └── taskmanager/
│               ├── App.java
│               ├── Task.java
│               └── TaskManager.java
├── README.md
```

## Customization
Feel free to extend the project by adding features like:
- Task priority levels (e.g., Low, Medium, High).
- Save tasks to a file for persistence.
- Load tasks from a file on startup.

## Author
This project was developed to showcase a clean and modular Java-based application for task management.