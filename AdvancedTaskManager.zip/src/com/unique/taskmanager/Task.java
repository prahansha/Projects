package com.unique.taskmanager;

public class Task {
    private String title;
    private String category;
    private String dueDate;
    private boolean isCompleted;

    public Task(String title, String category, String dueDate) {
        this.title = title;
        this.category = category;
        this.dueDate = dueDate;
        this.isCompleted = false;
    }

    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    public String getDueDate() {
        return dueDate;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void markCompleted() {
        this.isCompleted = true;
    }

    @Override
    public String toString() {
        return "Task [Title: " + title + ", Category: " + category + ", Due Date: " + dueDate + ", Completed: " + isCompleted + "]";
    }
}