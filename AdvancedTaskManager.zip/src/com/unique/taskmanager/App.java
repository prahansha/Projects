package com.unique.taskmanager;

import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        TaskManager taskManager = new TaskManager();
        taskManager.run();
    }
}